import {useMemo,useCallback,useEffect,useState,useRef} from 'react';
import {ReactFlow,ReactFlowProvider,Background,Controls,MiniMap,Handle,Position,applyNodeChanges,applyEdgeChanges,useReactFlow,useNodesInitialized,type Node,type NodeProps,type NodeChange,type EdgeChange,type Connection} from '@xyflow/react';
import {Activity,Volume2,SlidersHorizontal,AudioWaveform} from 'lucide-react';
import type {Patch,Catalog,Block} from '../types';
import '@xyflow/react/dist/style.css';
type AudioNode = Node<{block:Block;catalog:Catalog},'audio'>;
function BlockNode({data,selected}:NodeProps<AudioNode>){const b=data.block,d=data.catalog[b.type];if(!d)return null;const generator=d.inputs===0;const Icon=b.type==='output'?Volume2:generator?AudioWaveform:b.type==='sum'?Activity:SlidersHorizontal;
 return <div className={`audio-node ${selected?'chosen':''} ${generator?'generator':''} ${b.type==='output'?'output':''}`}>
 {!generator&&<Handle type="target" position={Position.Left}/>}<div className="node-kicker">{d.category}</div><div className="node-title"><Icon size={16}/><span>{b.label||d.label}</span></div><div className="node-values">{Object.entries(b.parameters).slice(0,2).map(([k,v])=><span key={k}>{k} <b>{Math.abs(v)<.01&&v!==0?v.toExponential(1):Number(v.toFixed(2))}</b> {d.parameters[k]?.unit}</span>)}{!Object.keys(b.parameters).length&&<span>{d.inputs<0?'Σ entrées':b.type==='output'?'mono · signal brut':'Signal'}</span>}</div>{b.type!=='output'&&<Handle type="source" position={Position.Right}/>}</div>
}
const nodeTypes={audio:BlockNode};
function Inner({patch,catalog,onChange,onSelect,selected,disabled}:Props){const flow=useReactFlow();
 const [nodes,setNodes]=useState<AudioNode[]>([]);
 useEffect(()=>setNodes(previous=>patch.nodes.map(b=>({...previous.find(n=>n.id===b.id),id:b.id,type:'audio' as const,position:b.position,data:{block:b,catalog},selected:b.id===selected}))),[patch.nodes,catalog,selected]);
 const initialized=useNodesInitialized();const fitted=useRef('');const nodeKey=patch.nodes.map(n=>n.id).join('|');
 useEffect(()=>{if(initialized&&fitted.current!==nodeKey){fitted.current=nodeKey;void flow.fitView({padding:.2,duration:200})}},[initialized,nodeKey,flow]);
 const edges=useMemo(()=>patch.edges.map(e=>({...e,type:'smoothstep',style:{stroke:'#789864',strokeWidth:1.6}})),[patch.edges]);
 const changeNodes=useCallback((changes:NodeChange<AudioNode>[])=>{if(disabled&&changes.every(c=>c.type!=='dimensions'))return;const select=changes.find(c=>c.type==='select'&&c.selected);if(select&&'id'in select)onSelect(select.id);const updated=applyNodeChanges(changes,nodes);setNodes(updated);if(changes.some(c=>c.type==='position'||c.type==='remove')){const ids=new Set(updated.map(n=>n.id));onChange({...patch,nodes:updated.map(n=>({...n.data.block,position:n.position})),edges:patch.edges.filter(e=>ids.has(e.source)&&ids.has(e.target))})}},[nodes,patch,onChange,onSelect,disabled]);
 const changeEdges=(changes:EdgeChange[])=>{if(!disabled)onChange({...patch,edges:applyEdgeChanges(changes,edges).map(({id,source,target})=>({id,source,target}))})};
 const connect=(c:Connection)=>{if(disabled||!c.source||!c.target||c.source===c.target||patch.edges.some(e=>e.source===c.source&&e.target===c.target))return;onChange({...patch,edges:[...patch.edges,{id:crypto.randomUUID(),source:c.source,target:c.target}]})};
 return <div className="graph-wrap" onDragOver={e=>{e.preventDefault();e.dataTransfer.dropEffect='copy'}} onDrop={e=>{e.preventDefault();if(disabled)return;const type=e.dataTransfer.getData('application/resonant');if(!catalog[type])return;const position=flow.screenToFlowPosition({x:e.clientX,y:e.clientY});const id=crypto.randomUUID();onChange({...patch,nodes:[...patch.nodes,{id,type,label:catalog[type].label,parameters:Object.fromEntries(Object.entries(catalog[type].parameters).map(([k,p])=>[k,p.default])),position,reason:'Bloc ajouté manuellement.'}]});onSelect(id)}}>
 <ReactFlow nodes={nodes} edges={edges} nodeTypes={nodeTypes} onNodesChange={changeNodes} onEdgesChange={changeEdges} onConnect={connect} onNodeClick={(_,n)=>onSelect(n.id)} onPaneClick={()=>onSelect('')} fitView fitViewOptions={{padding:.2}} minZoom={.15} maxZoom={2} colorMode="dark" deleteKeyCode={disabled?null:['Backspace','Delete']} nodesDraggable={!disabled} nodesConnectable={!disabled}><Background color="#33414e" gap={22} size={1}/><Controls showInteractive={false}/><MiniMap nodeColor={n=>(n.data as {block:Block}).block.type==='modal'?'#b4ed79':'#506474'} maskColor="#0e151cbb" pannable zoomable/></ReactFlow>
 <span className="canvas-caption">Déplacer · Relier les ports · Molette pour zoomer</span></div>
}
interface Props{patch:Patch;catalog:Catalog;onChange:(p:Patch)=>void;onSelect:(id:string)=>void;selected:string;disabled:boolean}
export function Graph(props:Props){return <ReactFlowProvider><Inner {...props}/></ReactFlowProvider>}
